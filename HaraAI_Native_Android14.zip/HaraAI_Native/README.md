# Hara AI Native APK

This is a native Android WebView wrapper for https://hackerai.co/ designed to install directly on Android 14.

- Package: com.hara.ai
- minSdk: 24
- targetSdk: 34
- compileSdk: 35
- No WebAPK/Chrome dependency

## Build

On GitHub: upload this project, open Actions, run **Build Hara AI APK**, then download the `HaraAI-debug` artifact.
