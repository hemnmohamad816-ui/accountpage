import {
  canUseExtraUsage,
  canUseMaxModel,
  normalizeMaxModelForSubscription,
  normalizeSelectedModelForSubscription,
  normalizeSelectedModelOverrideForSubscription,
  withExtraUsageBillingForModel,
} from "../chat";

describe("normalizeSelectedModelForSubscription", () => {
  it("forces free users to auto even when a paid model is stored", () => {
    expect(normalizeSelectedModelForSubscription("haraai-pro", "free")).toBe(
      "auto",
    );
    expect(normalizeSelectedModelForSubscription("haraai-max", "free")).toBe(
      "auto",
    );
  });

  it("preserves paid users' selected model and defaults missing values to auto", () => {
    expect(normalizeSelectedModelForSubscription("haraai-pro", "pro")).toBe(
      "haraai-pro",
    );
    expect(normalizeSelectedModelForSubscription("haraai-max", "ultra")).toBe(
      "haraai-max",
    );
    expect(normalizeSelectedModelForSubscription(null, "ultra")).toBe("auto");
    expect(normalizeSelectedModelForSubscription(undefined, "team")).toBe(
      "auto",
    );
  });

  it("preserves paid Max until entitlement-aware routing", () => {
    expect(normalizeSelectedModelForSubscription("haraai-max", "pro")).toBe(
      "haraai-max",
    );
    expect(
      normalizeSelectedModelForSubscription("haraai-max", "pro-plus"),
    ).toBe("haraai-max");
    expect(normalizeSelectedModelForSubscription("haraai-max", "team")).toBe(
      "haraai-max",
    );
  });
});

describe("normalizeSelectedModelOverrideForSubscription", () => {
  it("forces free users to auto even when no override was sent", () => {
    expect(normalizeSelectedModelOverrideForSubscription(null, "free")).toBe(
      "auto",
    );
    expect(
      normalizeSelectedModelOverrideForSubscription(undefined, "free"),
    ).toBe("auto");
  });

  it("preserves missing paid overrides as undefined", () => {
    expect(
      normalizeSelectedModelOverrideForSubscription(undefined, "pro"),
    ).toBeUndefined();
    expect(
      normalizeSelectedModelOverrideForSubscription(null, "ultra"),
    ).toBeUndefined();
  });

  it("preserves explicit paid overrides until entitlement-aware routing", () => {
    expect(
      normalizeSelectedModelOverrideForSubscription("haraai-max", "ultra"),
    ).toBe("haraai-max");
    expect(
      normalizeSelectedModelOverrideForSubscription("haraai-max", "team"),
    ).toBe("haraai-max");
    expect(
      normalizeSelectedModelOverrideForSubscription("haraai-pro", "team"),
    ).toBe("haraai-pro");
  });
});

describe("Max model entitlement helpers", () => {
  it("allows Max for Ultra users", () => {
    expect(canUseMaxModel("ultra")).toBe(true);
  });

  it("allows Max for paid users with usable extra usage", () => {
    const extraUsageConfig = {
      enabled: true,
      hasBalance: true,
      balanceDollars: 10,
      autoReloadEnabled: false,
    };

    expect(canUseExtraUsage(extraUsageConfig)).toBe(true);
    expect(canUseMaxModel("pro", { extraUsageConfig })).toBe(true);
    expect(
      normalizeMaxModelForSubscription("haraai-max", "pro", {
        extraUsageConfig,
      }),
    ).toBe("haraai-max");
  });

  it("downgrades Max for paid users without usable extra usage", () => {
    expect(canUseMaxModel("pro")).toBe(false);
    expect(normalizeMaxModelForSubscription("haraai-max", "pro")).toBe(
      "haraai-pro",
    );
    expect(
      normalizeMaxModelForSubscription("haraai-max", "pro-plus", {
        extraUsageConfig: {
          enabled: true,
          hasBalance: true,
          balanceDollars: 10,
          autoReloadEnabled: false,
          monthlyRemainingDollars: 0,
        },
      }),
    ).toBe("haraai-pro");
  });

  it("bills Max entirely through Extra Usage outside Ultra", () => {
    const extraUsageConfig = {
      enabled: true,
      hasBalance: true,
      autoReloadEnabled: false,
    };

    expect(
      withExtraUsageBillingForModel(
        extraUsageConfig,
        "haraai-max",
        "pro-plus",
      ),
    ).toEqual({
      ...extraUsageConfig,
      chargeAllUsage: true,
    });
    expect(
      withExtraUsageBillingForModel(extraUsageConfig, "haraai-max", "ultra"),
    ).toBe(extraUsageConfig);
    expect(
      withExtraUsageBillingForModel(
        extraUsageConfig,
        "haraai-pro",
        "pro-plus",
      ),
    ).toBe(extraUsageConfig);
  });
});
