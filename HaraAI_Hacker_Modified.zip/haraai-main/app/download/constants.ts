const GITHUB_RELEASE_BASE =
  "https://github.com/haraai-tech/haraai/releases/latest/download";

export const downloadLinks = {
  macos: `${GITHUB_RELEASE_BASE}/HaraAI-universal.dmg`,
  windows: `${GITHUB_RELEASE_BASE}/HaraAI-windows-x64.exe`,
  linuxAppImage: `${GITHUB_RELEASE_BASE}/HaraAI-linux-x64.AppImage`,
  linuxArm64AppImage: `${GITHUB_RELEASE_BASE}/HaraAI-linux-arm64.AppImage`,
  linuxDeb: `${GITHUB_RELEASE_BASE}/HaraAI-linux-x64.deb`,
  linuxArm64Deb: `${GITHUB_RELEASE_BASE}/HaraAI-linux-arm64.deb`,
};
